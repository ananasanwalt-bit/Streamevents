# StreamEvents

Eine online-fähige erste Full-Stack-Version für dein Projekt:
- Benutzer-Login/Registrierung
- PostgreSQL-Datenbank
- TikTok Login Kit OAuth 2.0 Web-Flow
- TikTok Webhook-Endpunkt
- Event-Regeln
- Browser-Spiel
- Game-WebSocket
- Docker Compose

## Lokal starten
1. `.env.example` nach `.env` kopieren.
2. `JWT_SECRET` ändern.
3. `docker compose up --build`
4. http://localhost:3000 öffnen.

## TikTok
In deiner TikTok Developer App musst du Login Kit für Web konfigurieren und eine statische HTTPS Redirect URI registrieren. Für lokale Entwicklung kann zunächst eine separate Entwicklungsumgebung genutzt werden; TikTok beschreibt für Web Redirect URIs die HTTPS-Anforderung. Der Client Secret bleibt ausschließlich auf dem Server.

Aktuell ist `user.info.basic` als Standard-Scope vorgesehen. Zusätzliche Scopes benötigen je nach Produkt eine Freigabe. Die tatsächlichen LIVE-Follow/Like/Gift-Ereignisse müssen über die für deine TikTok-App verfügbaren/approved Produkte angebunden werden; dieser Starter verarbeitet Webhooks generisch, damit die Event-Payloads anschließend auf deine Event Engine gemappt werden können.

## Produktion
Empfohlen:
- App hinter HTTPS
- starke JWT_SECRET
- PostgreSQL mit verschlüsselter Verbindung
- Secrets nur als Environment Variables
- Reverse Proxy (z.B. Caddy/Nginx)
- Backups
- Rate Limiting / CSRF-Strategie für produktive Erweiterungen
- Webhook-Signatur/Authentizitätsprüfung gemäß dem für dein TikTok-Produkt geltenden Verfahren


## Enthalten
- 6 Interactive Browser-Games
- Streamer-Ziel: 10 Wins
- 12 Gift-Zuordnungen pro Spiel
- Follow/Like/Share-Trigger
- 🎁 Gift testen Button
- WebSocket Game Bridge
- TikTok OAuth/Webhook Backend
- PostgreSQL + Docker

Die Demo-Giftliste ist nur für Tests. In Produktion wird die Gift-Auswahl mit den tatsächlich von der verbundenen TikTok-LIVE-Integration gelieferten Gifts synchronisiert.
